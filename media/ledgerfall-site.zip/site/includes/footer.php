<footer>
  <div class="wrap">
    <a href="index.php" class="brand">
      <img src="images/logo-icon.svg" alt="">
      <?php echo SITE_NAME; ?>
    </a>
    <div class="foot-links">
      <a href="<?php echo YOUTUBE_CHANNEL_URL; ?>" target="_blank" rel="noopener">YouTube</a>
      <a href="<?php echo DISCORD_URL; ?>" target="_blank" rel="noopener">Discord</a>
      <a href="<?php echo GITHUB_URL; ?>" target="_blank" rel="noopener">GitHub</a>
      <a href="roadmap.php">Roadmap</a>
    </div>
    <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. Built for Minecraft Java servers. Not affiliated with Mojang or Microsoft.</p>
  </div>
</footer>
<script src="js/main.js"></script>
</body>
</html>
