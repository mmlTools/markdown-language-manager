<?php require_once __DIR__ . '/config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo isset($page_title) ? $page_title . ' — ' . SITE_NAME : SITE_NAME; ?></title>
  <meta name="description" content="<?php echo SITE_TAGLINE; ?>">
  <link rel="icon" type="image/svg+xml" href="images/logo-icon.svg">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@500;600;700&family=Crimson+Text:ital,wght@0,400;0,600;1,400&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header>
  <nav class="nav">
    <a href="index.php" class="brand">
      <img src="images/logo-icon.svg" alt="">
      <?php echo SITE_NAME; ?>
    </a>
    <div class="nav-links">
      <a href="index.php#npcs">NPCs</a>
      <a href="index.php#features">Features</a>
      <a href="roadmap.php">Roadmap</a>
      <a href="scrolls.php">Scrolls</a>
      <a href="clips.php">Clips</a>
      <a href="<?php echo DISCORD_URL; ?>" target="_blank" rel="noopener">Discord</a>
    </div>
  </nav>
</header>
