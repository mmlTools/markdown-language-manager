<?php
// ---------------------------------------------------------
// Ledgerfall — site configuration
// Edit these values to customize branding & links.
// ---------------------------------------------------------

define('SITE_NAME', 'Ledgerfall');
define('SITE_TAGLINE', 'A Skyblock built on trade, trust, and three very suspicious NPCs.');

define('YOUTUBE_CHANNEL_URL', 'https://www.youtube.com/@yourchannel');
define('DISCORD_URL', 'https://discord.gg/yourinvite');
define('GITHUB_URL', 'https://github.com/yourname/ledgerfall');

// Estimated launch — used on the roadmap page
define('LAUNCH_TARGET', 'Q1 — 8 months out');

// Latest YouTube clips (replace VIDEO_ID with real YouTube IDs)
$latest_clips = [
    [
        'id' => 'dQw4w9WgXcQ',
        'title' => 'Devlog #1 — The Clerk\'s first quest line',
        'tag' => 'Devlog',
    ],
    [
        'id' => 'dQw4w9WgXcQ',
        'title' => 'O(1) cobble generator caching, explained',
        'tag' => 'Tech Breakdown',
    ],
    [
        'id' => 'dQw4w9WgXcQ',
        'title' => 'Catching The Thief with an egg (it went wrong)',
        'tag' => 'Clip',
    ],
];
