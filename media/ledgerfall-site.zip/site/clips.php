<?php
$page_title = 'Clips';
require_once 'includes/header.php';
require_once 'includes/config.php';
?>

<section style="padding-bottom: 0;">
  <div class="wrap">
    <div class="section-head">
      <span class="eyebrow">Devlogs &amp; clips</span>
      <h2>Latest from the workshop</h2>
      <p class="lede" style="margin: 0 auto;">
        Short clips, devlogs, and the occasional disaster — posted as new systems
        come online. Replace the video IDs in <code>includes/config.php</code> with
        your real uploads.
      </p>
    </div>
    <img src="images/divider.svg" class="divider" alt="">
  </div>
</section>

<section style="padding-top: 0;">
  <div class="wrap">
    <div class="video-grid">
      <?php foreach ($latest_clips as $clip): ?>
        <div class="video-card">
          <div class="video-frame">
            <iframe
              src="https://www.youtube.com/embed/<?php echo htmlspecialchars($clip['id']); ?>"
              title="<?php echo htmlspecialchars($clip['title']); ?>"
              loading="lazy"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowfullscreen></iframe>
          </div>
          <div class="video-meta">
            <span><?php echo htmlspecialchars($clip['tag']); ?></span>
            <h4><?php echo htmlspecialchars($clip['title']); ?></h4>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <div class="youtube-cta">
      <a class="btn solid" href="<?php echo YOUTUBE_CHANNEL_URL; ?>" target="_blank" rel="noopener">
        Subscribe for more
      </a>
    </div>
  </div>
</section>

<?php require_once 'includes/footer.php'; ?>
