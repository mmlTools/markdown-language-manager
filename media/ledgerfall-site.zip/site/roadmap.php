<?php
$page_title = 'Roadmap';
require_once 'includes/header.php';

$roadmap = [
    [
        'when' => 'Month 1 — Foundations',
        'status' => 'done',
        'title' => 'Storage, performance core & island bootstrap',
        'desc' => 'The skeleton everything else builds on: dual storage backends, async queries, and the first island generation with starter NPC eggs.',
        'tags' => ['HikariCP', 'Flat-file / MySQL toggle', 'Async task queue', 'Island schematic loader'],
    ],
    [
        'when' => 'Month 2 — The Three NPCs',
        'status' => 'active',
        'title' => 'Auctioneer, Thief & Clerk core GUIs',
        'desc' => 'All three signature NPCs go in: invulnerable, un-pushable, and wired into their respective menus. Price-limit config for the Auctioneer ships first.',
        'tags' => ['Auction House GUI', 'Black Market GUI', 'Quest Master GUI', 'Min/max price config'],
    ],
    [
        'when' => 'Month 2 — Egg Mechanics',
        'status' => 'active',
        'title' => 'The catch-and-relocate system',
        'desc' => 'Throwing an egg at your own NPC relocates it. Throwing one at any NPC rolls a catch chance — succeed and it drops its egg, fail and it\'s gone for good.',
        'tags' => ['Catch %', 'Egg as tradeable item', 'Risk/reward loop'],
    ],
    [
        'when' => 'Month 3 — Cobblestone Generator',
        'status' => 'planned',
        'title' => 'O(1) generator engine & leveling',
        'desc' => 'Pre-cached weight arrays, optimized block placement flags, and the XP system that ties generator level to the shared island instance.',
        'tags' => ['Flat-array caching', 'BlockFromToEvent', 'Generator XP', 'Cobble Gen XP Scrolls'],
    ],
    [
        'when' => 'Month 4 — Island Permissions & Co-Op',
        'status' => 'planned',
        'title' => 'Visit modes, trust system & Guest Book',
        'desc' => 'Friendly / Carnage / Demolition / FFA modes via chat command, the co-op trust system, and the Enchanting-Table Guest Book that shows owner, members, and progress.',
        'tags' => ['/is settings', 'Co-op trust', 'Guest Book GUI', 'Shared vs individual progress'],
    ],
    [
        'when' => 'Month 5 — Trophy Hall & Mob Economy',
        'status' => 'planned',
        'title' => 'Achievement trophies and the loot economy',
        'desc' => 'Physical trophy heads that raise or lower your island\'s rank, plus the high-tier mob drop economy that feeds the crafting system.',
        'tags' => ['Trophy tiers', 'Server leaderboard', 'Mob drop scaling', 'AH/Black Market integration'],
    ],
    [
        'when' => 'Month 6 — Scrolls & Enchantments, Part 1',
        'status' => 'planned',
        'title' => 'First 10 scrolls + first 10 enchantments',
        'desc' => 'Modular crafting recipes go live for the first half of the master list — Fly, Magnet, Repair, and Hopper Link scrolls; Vein Miner, Auto-Smelt, and Telekinesis enchants among them.',
        'tags' => ['Configurable recipes', 'Cooldowns & success rates', '10 scrolls', '10 enchants'],
    ],
    [
        'when' => 'Month 7 — Scrolls & Enchantments, Part 2 + Fishing',
        'status' => 'planned',
        'title' => 'Remaining scrolls/enchants and custom fishing',
        'desc' => 'The second half of the master list ships alongside the full localized fishing overhaul — tiered loot tables cached for high-population servers.',
        'tags' => ['10 more scrolls', '10 more enchants', 'Fishing loot tiers', 'Sea Collector / Abyssal Hook'],
    ],
    [
        'when' => 'Month 8 — Storage QoL, Polish & Launch',
        'status' => 'planned',
        'title' => 'Filter hoppers, auto-sort, compactor & launch candidate',
        'desc' => 'Final quality-of-life pass — filter hoppers, auto-sorting chests, void item vacuum, the material compactor — plus full server-stress testing before release.',
        'tags' => ['Filter hoppers', 'Auto-sort chests', 'Void vacuum', 'Stress test', 'Launch'],
    ],
];

$status_labels = [
    'done' => 'Shipped',
    'active' => 'In Progress',
    'planned' => 'Planned',
];
$status_seals = [
    'done' => 'seal-progress.svg',
    'active' => 'seal-planned.svg',
    'planned' => 'seal-locked.svg',
];
?>

<section style="padding-bottom: 0;">
  <div class="wrap">
    <div class="section-head">
      <span class="eyebrow">The road ahead</span>
      <h2>Eight months, nine milestones</h2>
      <p class="lede" style="margin: 0 auto;">
        Target launch: <strong style="color: var(--gold);"><?php echo LAUNCH_TARGET; ?></strong>.
        Each milestone is sealed until its month begins — green wax means it's done,
        gold means it's underway, and red means it's still locked away.
      </p>
    </div>
    <img src="images/divider.svg" class="divider" alt="">
  </div>
</section>

<section style="padding-top: 0;">
  <div class="wrap">
    <div class="roadmap">
      <?php foreach ($roadmap as $item): ?>
        <div class="road-item">
          <img class="seal" src="images/<?php echo $status_seals[$item['status']]; ?>" alt="<?php echo $status_labels[$item['status']]; ?> status seal">
          <div class="road-card">
            <span class="when"><?php echo htmlspecialchars($item['when']); ?>
              <span class="status-pill <?php echo $item['status']; ?>"><?php echo $status_labels[$item['status']]; ?></span>
            </span>
            <h4><?php echo htmlspecialchars($item['title']); ?></h4>
            <p><?php echo htmlspecialchars($item['desc']); ?></p>
            <ul>
              <?php foreach ($item['tags'] as $tag): ?>
                <li><?php echo htmlspecialchars($tag); ?></li>
              <?php endforeach; ?>
            </ul>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php require_once 'includes/footer.php'; ?>
