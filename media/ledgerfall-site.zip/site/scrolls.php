<?php
$page_title = 'Scrolls & Enchants';
require_once 'includes/header.php';

$scrolls = [
    'Platform Builder Scroll' => 'Select a 3D region (left-click point A, right-click point B) and instantly fill it from your inventory. Capped at 500 blocks.',
    'Fly Scroll' => 'Temporary creative-style flight inside your island boundary. The timer pauses while you\'re offline or off-island.',
    'Cobble Generator XP Scroll' => 'Injects a flat chunk of XP directly into your island\'s generator level tracker.',
    'Repair Scroll' => 'Fully restores the durability of whatever\'s in your main hand.',
    'Haste / Speed Scroll' => 'Haste II and Speed II for 20 minutes — built for grinding sessions.',
    'Magnet Scroll' => 'Everything you break, harvest, or kill teleports straight into your inventory for 15 minutes.',
    'Feed & Heal Scroll' => 'Tops up health and hunger, and clears negative effects like Poison or Wither.',
    'Hopper Wireless Link Scroll' => 'Link a hopper to a chest — for 2 hours, anything the hopper catches teleports to that chest, any distance.',
    'Chunk Fertilizer Scroll' => 'Crops, saplings, and nether warts grow 5x faster across a 16x16 chunk for 10 minutes.',
    'Island Boundary Expander Scroll' => 'A rare endgame scroll that permanently pushes your island\'s claim radius outward.',
    'Mob Spawner Booster Scroll' => 'Right-click a spawner to cut its spawn delay by 25% for an hour.',
    'Expresso Mining Scroll' => 'For 10 minutes, mining an ore shatters every identical block within 3 blocks.',
    'Spawner Silencer Scroll' => 'Permanently mutes a spawner\'s idle sound — a quality-of-life fix for big mob farms.',
    'Aquatic Bait Scroll' => 'Halves your fishing wait time for 30 minutes.',
    'Merchant Discount Scroll' => '15% off everything The Thief sells, for 15 minutes.',
    'Trophy Booster Scroll' => 'Doubles milestone progress for your next 1,000 blocks broken or mobs slain.',
    'Void Fall Negation Scroll' => 'For an hour, falling into the void teleports you home safely — no item loss, no durability hit.',
    'Clear Weather Scroll' => 'Resets your island\'s weather to clear skies for 2 hours.',
    'Minion Fuel Scroll' => 'Boosts any placed automation minion\'s action speed by 50% for 30 minutes.',
    'Scroll of the Deep' => 'Permanently infuses your armor with Water Breathing and Night Vision for an hour.',
];

$enchants = [
    'Blast Mining (Pickaxe)' => 'Breaks up to 3 connected ores of the same type in one swing — all of it counts toward generator XP.',
    'Auto-Smelt (Pickaxe)' => 'Iron, gold, and ancient debris come out of the ground already smelted.',
    'Telekinesis (Tools)' => 'Mined or harvested items skip the ground entirely and go straight to your inventory.',
    'Lumberjack (Axe)' => 'Break one log, drop the whole tree above it.',
    'Replant (Hoe)' => 'Harvesting a grown crop auto-consumes a seed and replants it instantly.',
    'Mob Swarm / Cleave (Sword)' => 'A sweep attack has a chance to mirror damage onto every nearby mob of the same type.',
    'Loot Multiplier (Sword)' => 'A configurable chance to double rare drops — Blaze Rods, Ghast Tears, Ender Pearls.',
    'Beheading (Sword)' => 'A small chance to drop a mob\'s head on the kill.',
    'Experience Vampire (Sword/Tools)' => 'Siphons a 1.5x multiplier onto your overall XP and currency gains.',
    'Void Insurance (Chestplate)' => 'Falling into the void teleports you home, costing half your health and 25% chestplate durability.',
    'Hydro-Tillage (Hoe)' => 'Tilled soil stays permanently watered — crops grow at full speed with no water nearby, ever.',
    'Photosynthesis (Helmet)' => 'Standing in direct sunlight slowly repairs all your equipped armor.',
    'Spring-Step (Boots)' => 'Permanent Speed I and Jump Boost I anywhere on your own or trusted islands.',
    'Harvester Fortune (Hoe)' => 'Levels I–III scale up your chance to triple crop drops on harvest.',
    'Molten Touch (Sword)' => '25% chance to ignite targets — and any meat they drop comes out pre-cooked.',
    'Gorgon Eye (Bow/Crossbow)' => '5% chance for a landed shot to apply Slowness V for 3 seconds.',
    'Sea Collector (Fishing Rod)' => 'A small chance to double whatever you catch.',
    'Abyssal Hook (Fishing Rod)' => 'Skews your fishing rolls hard toward rare, epic, and legendary loot.',
    'Unbreakable Core (Armor Set)' => '15% chance that taking damage costs zero durability across your whole armor set.',
    'Titanium Silk Touch (Axe)' => 'Break an active mob spawner with this and it drops intact — entity profile and all.',
];
?>

<section style="padding-bottom: 0;">
  <div class="wrap">
    <div class="section-head">
      <span class="eyebrow">The master list</span>
      <h2>20 scrolls. 20 enchantments. All modular.</h2>
      <p class="lede" style="margin: 0 auto;">
        Every recipe, duration, cooldown, and success rate below is config-driven —
        server owners can rebalance the entire economy without touching code.
      </p>
    </div>
    <img src="images/divider.svg" class="divider" alt="">
  </div>
</section>

<section style="padding-top: 0;">
  <div class="wrap">
    <h3 style="margin-bottom: 20px;">Consumable Scrolls</h3>
    <div class="accordion" style="margin-bottom: 60px;">
      <?php foreach ($scrolls as $name => $desc): ?>
        <div class="acc-item">
          <div class="acc-header">
            <span><?php echo htmlspecialchars($name); ?></span>
            <span class="plus">+</span>
          </div>
          <div class="acc-body">
            <div class="acc-body-inner"><?php echo htmlspecialchars($desc); ?></div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <h3 style="margin-bottom: 20px;">Permanent Enchantments</h3>
    <div class="accordion">
      <?php foreach ($enchants as $name => $desc): ?>
        <div class="acc-item">
          <div class="acc-header">
            <span><?php echo htmlspecialchars($name); ?></span>
            <span class="plus">+</span>
          </div>
          <div class="acc-body">
            <div class="acc-body-inner"><?php echo htmlspecialchars($desc); ?></div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php require_once 'includes/footer.php'; ?>
