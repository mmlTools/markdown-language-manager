<?php
$page_title = 'Home';
require_once 'includes/header.php';
?>

<section class="hero">
  <div class="wrap hero-grid">
    <div>
      <span class="eyebrow">A Skyblock Plugin · In Development</span>
      <h1>Three NPCs.<br>One island.<br><span>Endless leverage.</span></h1>
      <p class="lede">
        <?php echo SITE_NAME; ?> rebuilds Skyblock around trade and trust: an Auctioneer who sets the
        market, a Thief who undercuts it, and a Clerk who keeps everyone busy. Trapdoor spawners,
        catchable NPCs, and a cobblestone generator that won't lag your server at 200 players.
      </p>
      <div class="btn-row">
        <a href="roadmap.php" class="btn solid">View the roadmap</a>
        <a href="clips.php" class="btn">Watch the latest clips</a>
      </div>
    </div>
    <div class="hero-art">
      <img src="images/hero-island.svg" alt="A floating skyblock island with three NPC merchant towers">
    </div>
  </div>

  <div class="wrap stats">
    <div class="stat"><div class="num">3</div><div class="label">Core NPCs</div></div>
    <div class="stat"><div class="num">20</div><div class="label">Custom Scrolls</div></div>
    <div class="stat"><div class="num">20</div><div class="label">Custom Enchants</div></div>
    <div class="stat"><div class="num">8mo</div><div class="label">To Launch</div></div>
  </div>
</section>

<section id="npcs">
  <div class="wrap">
    <div class="section-head">
      <span class="eyebrow">Meet the cast</span>
      <h2>Every island starts with three strangers</h2>
      <p class="lede" style="margin: 0 auto;">Crack open your starter chest and you'll find three spawn eggs.
      What you do with them — trade through them, trust them, or chuck an egg at them — shapes your whole economy.</p>
    </div>

    <img src="images/divider.svg" class="divider" alt="">

    <div class="npc-grid">
      <div class="npc-card">
        <img src="images/npc-auctioneer.svg" alt="The Auctioneer">
        <span class="role">Player Market</span>
        <h3>The Auctioneer</h3>
        <p>Your localized auction house. Lists go through a GUI with server-enforced
        min and max prices per item, so nobody corners the market on day one — and
        nobody undercuts it into worthlessness either.</p>
      </div>
      <div class="npc-card">
        <img src="images/npc-thief.svg" alt="The Thief">
        <span class="role">Black Market</span>
        <h3>The Thief</h3>
        <p>Sells contraband the Auctioneer won't touch. His spawner sub-menu rotates
        daily with brutal odds and even more brutal prices — the server's primary
        money sink, and the rarest thing you'll ever see in his stock.</p>
      </div>
      <div class="npc-card">
        <img src="images/npc-clerk.svg" alt="The Clerk">
        <span class="role">Quest Master</span>
        <h3>The Clerk</h3>
        <p>Hands out gather, break, craft, and fishing quests — up to three active
        at once, tracked individually per player even on a shared island. Turn one
        in, claim the reward, take the next.</p>
      </div>
    </div>
  </div>
</section>

<section class="alt" id="features">
  <div class="wrap">
    <div class="section-head">
      <span class="eyebrow">Under the hood</span>
      <h2>Built to survive a full server</h2>
      <p class="lede" style="margin: 0 auto;">Every system here was designed against one question:
      what happens when 200 players are mining, fishing, and trading at once?</p>
    </div>

    <img src="images/divider.svg" class="divider" alt="">

    <div class="feature-grid">
      <div class="feature">
        <img src="images/icon-scroll.svg" alt="">
        <h4>Async storage, either way</h4>
        <p>Flat-file or MySQL via HikariCP, toggled in one config line. Every query
        runs off the main thread — your TPS never waits on the database.</p>
      </div>
      <div class="feature">
        <img src="images/icon-scroll.svg" alt="">
        <h4>O(1) generator lookups</h4>
        <p>Cobble generation chances are pre-baked into a flat array at startup.
        No file reads, no weight math, inside an event that fires thousands of
        times a minute.</p>
      </div>
      <div class="feature">
        <img src="images/icon-scroll.svg" alt="">
        <h4>The Pokémon mechanic</h4>
        <p>Throw an egg at an NPC to catch and relocate it. Throw one at the wrong
        thing and there's a real chance it's gone for good. Eggs are now a
        tradeable commodity.</p>
      </div>
      <div class="feature">
        <img src="images/icon-scroll.svg" alt="">
        <h4>Trophy Hall rankings</h4>
        <p>Server-wide leaderboard driven by physical trophy heads placed on your
        island. Place one, climb the board. Lose one, slide back down.</p>
      </div>
      <div class="feature">
        <img src="images/icon-scroll.svg" alt="">
        <h4>40 modular scrolls &amp; enchants</h4>
        <p>From Vein Miner to Telekinesis to a scroll that locates lost items in
        the void — every recipe, duration, and success rate is config-driven.</p>
      </div>
      <div class="feature">
        <img src="images/icon-scroll.svg" alt="">
        <h4>Self-sorting storage</h4>
        <p>Filter hoppers with whitelist/blacklist modes, one-click chest sorting,
        and a void vacuum that saves your drops instead of deleting them.</p>
      </div>
    </div>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="section-head">
      <span class="eyebrow">Set the rules</span>
      <h2>Four ways to open your island</h2>
      <p class="lede" style="margin: 0 auto;">One chat command cycles your island between four visitor
      modes — from "look but don't touch" to total chaos.</p>
    </div>

    <img src="images/divider.svg" class="divider" alt="">

    <table class="modes-table">
      <thead>
        <tr><th>Mode</th><th>PvP / PvE</th><th>Block Breaking</th><th>Description</th></tr>
      </thead>
      <tbody>
        <tr>
          <td class="mode-name">Friendly</td>
          <td><span class="tag off">Disabled</span></td>
          <td><span class="tag off">Disabled</span></td>
          <td>Visitors can only walk around and spectate.</td>
        </tr>
        <tr>
          <td class="mode-name">Carnage</td>
          <td><span class="tag on">Enabled</span></td>
          <td><span class="tag off">Disabled</span></td>
          <td>Combat is allowed, but the island structure is completely safe.</td>
        </tr>
        <tr>
          <td class="mode-name">Demolition</td>
          <td><span class="tag off">Disabled</span></td>
          <td><span class="tag on">Enabled</span></td>
          <td>Combat is disabled, but visitors are allowed to break blocks.</td>
        </tr>
        <tr>
          <td class="mode-name">FFA</td>
          <td><span class="tag on">Enabled</span></td>
          <td><span class="tag on">Enabled</span></td>
          <td>Free for all — complete chaos mode where everything can blow up.</td>
        </tr>
      </tbody>
    </table>
  </div>
</section>

<?php require_once 'includes/footer.php'; ?>
